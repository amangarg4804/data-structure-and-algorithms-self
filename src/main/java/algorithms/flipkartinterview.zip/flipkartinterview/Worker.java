package algorithms.flipkartinterview;

public class Worker {
    private boolean isBusy;

    public boolean isBusy() {
        return isBusy;
    }
    public void executeTask(Task task) {
        isBusy = true;
        task.run();
        isBusy = false;
    }
}
