package algorithms.flipkartinterview;

public interface Task {
    public void run();// just like Runnable
}
