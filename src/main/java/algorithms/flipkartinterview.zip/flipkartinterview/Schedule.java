package algorithms.flipkartinterview;

public interface Schedule {
}
